Pod::Spec.new do |s|
  s.name           = 'NovaMedia'
  s.version        = '0.1.0'
  s.summary        = 'NOVA native media bridge (AVAudioSession, Now Playing, remote commands)'
  s.homepage       = 'https://example.invalid'
  s.license        = 'MIT'
  s.author         = 'NOVA'
  s.platforms      = { :ios => '15.1' }
  s.source         = { :git => '' }
  s.static_framework = true
  s.dependency 'ExpoModulesCore'
  s.source_files   = '*.{h,m,swift}'
end
