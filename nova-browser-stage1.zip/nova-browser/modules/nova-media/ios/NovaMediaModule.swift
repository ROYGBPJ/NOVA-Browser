import ExpoModulesCore
import AVFoundation
import MediaPlayer

/// Native media bridge. The website's own player remains the source of playback:
/// this module configures the audio session, publishes Now Playing metadata that JS
/// received from the page, and forwards remote commands back to JS, which runs them
/// against the active page's player.
public class NovaMediaModule: Module {
  private var observers: [NSObjectProtocol] = []
  private var commandTargets: [(MPRemoteCommand, Any)] = []
  private var wasPlayingBeforeInterruption = false

  public func definition() -> ModuleDefinition {
    Name("NovaMedia")

    Events("onRemoteCommand", "onInterruption", "onRouteChange")

    OnCreate { self.activate() }
    OnDestroy { self.deactivate() }

    /// Configure the shared audio session for background playback.
    /// Requires UIBackgroundModes = ["audio"] (set in app.json).
    AsyncFunction("configureSession") { (mixWithOthers: Bool) throws in
      let session = AVAudioSession.sharedInstance()
      let options: AVAudioSession.CategoryOptions = mixWithOthers ? [.mixWithOthers] : []
      try session.setCategory(.playback, mode: .default, options: options)
      try session.setActive(true)
    }

    AsyncFunction("deactivateSession") { () throws in
      try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    /// Only fields the website actually provided are published; nothing is invented.
    AsyncFunction("setNowPlaying") { (info: [String: Any]) in
      var d: [String: Any] = [:]
      if let t = info["title"] as? String { d[MPMediaItemPropertyTitle] = t }
      if let a = info["artist"] as? String { d[MPMediaItemPropertyArtist] = a }
      if let al = info["album"] as? String { d[MPMediaItemPropertyAlbumTitle] = al }
      if let site = info["site"] as? String { d[MPMediaItemPropertyAlbumArtist] = site }
      if let dur = info["duration"] as? Double, dur.isFinite, dur > 0 { d[MPMediaItemPropertyPlaybackDuration] = dur }
      if let pos = info["position"] as? Double, pos.isFinite { d[MPNowPlayingInfoPropertyElapsedPlaybackTime] = pos }
      let playing = (info["state"] as? String) == "playing"
      d[MPNowPlayingInfoPropertyPlaybackRate] = playing ? 1.0 : 0.0
      MPNowPlayingInfoCenter.default().nowPlayingInfo = d
      MPNowPlayingInfoCenter.default().playbackState = playing ? .playing : .paused

      if let urlString = info["artworkUrl"] as? String, let url = URL(string: urlString) {
        self.loadArtwork(url)
      }
    }

    AsyncFunction("clearNowPlaying") { () in
      MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
      MPNowPlayingInfoCenter.default().playbackState = .stopped
    }

    /// Enable only commands the active website player supports.
    AsyncFunction("setSupportedCommands") { (caps: [String: Bool]) in
      let c = MPRemoteCommandCenter.shared()
      c.playCommand.isEnabled = caps["play"] ?? true
      c.pauseCommand.isEnabled = caps["pause"] ?? true
      c.togglePlayPauseCommand.isEnabled = caps["play"] ?? true
      c.nextTrackCommand.isEnabled = caps["next"] ?? false
      c.previousTrackCommand.isEnabled = caps["previous"] ?? false
      c.skipForwardCommand.isEnabled = caps["seek"] ?? false
      c.skipBackwardCommand.isEnabled = caps["seek"] ?? false
      c.changePlaybackPositionCommand.isEnabled = caps["seek"] ?? false
    }
  }

  // MARK: - Setup

  private func activate() {
    let c = MPRemoteCommandCenter.shared()
    c.skipForwardCommand.preferredIntervals = [15]
    c.skipBackwardCommand.preferredIntervals = [15]

    func bind(_ cmd: MPRemoteCommand, _ name: String) {
      let target = cmd.addTarget { [weak self] event in
        var body: [String: Any] = ["command": name]
        if let e = event as? MPChangePlaybackPositionCommandEvent { body["position"] = e.positionTime }
        if let e = event as? MPSkipIntervalCommandEvent { body["interval"] = e.interval }
        self?.sendEvent("onRemoteCommand", body)
        return .success
      }
      commandTargets.append((cmd, target))
    }
    bind(c.playCommand, "play")
    bind(c.pauseCommand, "pause")
    bind(c.togglePlayPauseCommand, "toggle")
    bind(c.nextTrackCommand, "next")
    bind(c.previousTrackCommand, "previous")
    bind(c.skipForwardCommand, "skipForward")
    bind(c.skipBackwardCommand, "skipBackward")
    bind(c.changePlaybackPositionCommand, "seek")

    let nc = NotificationCenter.default
    observers.append(nc.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] n in
      self?.handleInterruption(n)
    })
    observers.append(nc.addObserver(forName: AVAudioSession.routeChangeNotification, object: nil, queue: .main) { [weak self] n in
      self?.handleRouteChange(n)
    })
  }

  private func deactivate() {
    for (cmd, target) in commandTargets { cmd.removeTarget(target) }
    commandTargets.removeAll()
    observers.forEach { NotificationCenter.default.removeObserver($0) }
    observers.removeAll()
  }

  // MARK: - Interruptions and routes

  private func handleInterruption(_ n: Notification) {
    guard let raw = n.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
          let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
    switch type {
    case .began:
      sendEvent("onInterruption", ["phase": "began"])
    case .ended:
      let optRaw = n.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0
      let shouldResume = AVAudioSession.InterruptionOptions(rawValue: optRaw).contains(.shouldResume)
      // Re-activate the session; JS decides whether the website player may resume.
      try? AVAudioSession.sharedInstance().setActive(true)
      sendEvent("onInterruption", ["phase": "ended", "shouldResume": shouldResume])
    @unknown default: break
    }
  }

  private func handleRouteChange(_ n: Notification) {
    guard let raw = n.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt,
          let reason = AVAudioSession.RouteChangeReason(rawValue: raw) else { return }
    // oldDeviceUnavailable == headphones/Bluetooth disconnected: players should pause.
    sendEvent("onRouteChange", ["reason": reason == .oldDeviceUnavailable ? "deviceDisconnected" : "other"])
  }

  private func loadArtwork(_ url: URL) {
    guard url.scheme == "https" else { return }
    URLSession.shared.dataTask(with: url) { data, _, _ in
      guard let data = data, let image = UIImage(data: data) else { return }
      let art = MPMediaItemArtwork(boundsSize: image.size) { _ in image }
      DispatchQueue.main.async {
        var info = MPNowPlayingInfoCenter.default().nowPlayingInfo ?? [:]
        info[MPMediaItemPropertyArtwork] = art
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
      }
    }.resume()
  }
}
